./a.out -T0 300 -T 900 -dT 900 -tmin 1 -tmax 400000 -grid -3.14 3.14 0.10 -3.14 3.14 0.10 -3.14 3.14 0.10 -3.14 3.14 0.10 -pfrqMD 10 -dtMTD 500
#./executable_file  
#T0  physical system temperature
#T auxiliary variable temperature
#dT  delta T parameter for well-tempered metadynamics 
#tmin minimum number of steps to be taken for analysis
#tmax maximum number of steps to be taken for analysis
#grid gridmin gridmax gridsize of all CVs
#pfrqMD printing frequency of CVs
#dtMTD  hill deposition frequency

